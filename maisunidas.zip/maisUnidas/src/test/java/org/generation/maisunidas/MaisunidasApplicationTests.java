package org.generation.maisunidas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaisunidasApplicationTests {

	@Test
	void contextLoads() {
	}

}
