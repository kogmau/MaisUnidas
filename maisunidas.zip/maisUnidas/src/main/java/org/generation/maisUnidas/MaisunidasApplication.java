package org.generation.maisUnidas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaisunidasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaisunidasApplication.class, args);
	}

}
